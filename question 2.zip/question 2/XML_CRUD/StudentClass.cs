﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace XML_CRUD
{
    public class StudentClass
    {
        public string Name { get; set; }
        public int Class { get; set; }
        public string sub { get; set; }
    }
}